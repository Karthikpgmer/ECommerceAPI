const express = require('express');
var app = express();
var async = require('async');
//var mysql = require('mysql');
const router = express.Router();

router.get('/CheckApi', (req, res) => {
    res.send('SUCCESS');
});


module.exports = router;