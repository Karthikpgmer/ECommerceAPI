const express = require('express');
var cors = require('cors');
const path = require('path');
const http = require('http');
const bodyParser = require('body-parser');


const app = express();
const router = express.Router();
var parser = require('parse').Parse;

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(cors());
app.use(function (req, res, next) {
    res.header("Access-Control-Allow-Origin", "*")
    res.header('Access-Control-Allow-Methods', 'PUT,GET,POST,DELETE,OPTIONS');
    res.header("Access-control-Allow-Headers", "Origin,X-Requested-With,Content-Type,Accept");
    next();
});

//Angular Build folder
app.use(express.static(path.join(__dirname, 'dist')));


//Including api
const api = require('./NodeApi/ECommerceApi');
app.use('/ECommerceApi', api);

const port = process.env.PORT || '3000';
app.set('port', port);

/**
 * Create HTTP server.
 */
const server = http.createServer(app);

/**
 * Listen on provided port, on all network interfaces.
 */
server.listen(port, "0.0.0.0", () => console.log(`API running on localhost:${port}`));