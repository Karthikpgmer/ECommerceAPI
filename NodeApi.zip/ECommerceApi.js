const express = require('express');
var app = express();
var async = require('async');
var mysql = require('mysql');
const router = express.Router();
var config = require('./Config');

var mycon = mysql.createConnection({
    host: config.host,
    user: config.user,
    password: config.password,
    database: config.database,
    multipleStatements: true

});

router.get('/CheckApi', (req, res) => {
    res.send('SUCCESS');
});

router.get('/GetUserInfo', (req, res) => {
    //var data = req.body;
    var mysql_query = 'select * from ms_userinfo;';
    mycon.query(mysql_query, function (err, result, fields) {
        if (result.length != 0) {
            res.send({
                Result: result
            })
        }
        else {
            res.send({
                Result: 'Failed'
            })
        }
    })

    mycon.on('error', function(err) {
        console.log(err.code); // 'ER_BAD_DB_ERROR'
      });    
});


module.exports = router;