var userid = 'root';
var pwd = 'root';
var mode = 'dev';
var host = '127.0.0.1';
var db = 'ecommerce';
const config = {
    mode: mode,
    host: host,
    user: userid,
    password: pwd,
    database: db
    //secret:'ingramangularsecretley'
}
module.exports = config;

